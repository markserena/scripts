import maya.cmds as cmds
import maya.mel as mel
import __main__
import os

ms_selectedPath = ""

def convertInstances():  
    ## Use SOuP to convert the instances correctly. 
    ## I don't use the MASH one because it creates a piece of geometry for every frame and animates the visibility.
    ## Soup will animate the transforms.
    __main__.uninstancer_SOuP().main()  


def createBones():
    ## Please select a single instancer nodes       
    getSel = cmds.ls(sl=True)  
    ## The meshes are automatically selected, find the parent group and rename it  
    getPar = cmds.listRelatives(cmds.ls(sl=True), allParents=True )
    newName = cmds.rename(getPar, 'instancerSkinned_#')

    ## get all objects from newly created instancer conversion and group them seperately for neatness
    instancerGroup = newName
    skeletonGroup = cmds.group(name = '%s_skeleton' % instancerGroup, world = True, empty = True)
    masterGroup = cmds.group(name = '%s_Unreal_Export_FBX' % instancerGroup)
    newObjects = cmds.listRelatives(instancerGroup)

    ## For each object create a joint and copy the transform from the object to the rig
    ## And delete the previous channels and skin it.
    for obj in newObjects:
        i = 1
        nameSplit = obj.split('_')
        jointName = nameSplit[0] + '_' + nameSplit[1] + '_joint'
        ## find approx size via bounding box and place joints in min Y and max Y
        bbox = cmds.exactWorldBoundingBox( obj )
        cmds.select(clear = True)
        joint01 = cmds.joint(position = (0,bbox[1],0), name = 'base_' + jointName + '_%i' % i)
        replaceName = joint01.replace('base_', 'tip_')
        joint02 = cmds.joint(position = (0,bbox[4],0), name = replaceName)
        cmds.joint( joint01, edit = True, zeroScaleOrient = True, orientJoint = 'yzx', secondaryAxisOrient = 'zup')    
        cmds.currentTime(0)        
        cmds.copyKey( obj )
        cmds.pasteKey( joint01 )
        cmds.delete( obj , channels = True)
        cmds.select( joint01 , obj , replace = True)
        cmds.bindSkin()
        cmds.parent(joint01, skeletonGroup)
        i += 1
        
    ## Group everything into a master group ready for export
    cmds.parent(skeletonGroup, instancerGroup, masterGroup)
    cmds.select(masterGroup, replace = True)

def exportToFBX():
    ## Fix the path formatting.
    global ms_selectedPath
    ms_selectedPath = ms_selectedPath.replace('\\','/')
    
    ## Set defaults for FBX Exporting. Need smoothing groups/triangulation/Animation and other things to export correctly.
    mel.eval("FBXProperty Export|IncludeGrp|Geometry|SmoothingGroups -v 1;")
    mel.eval("FBXProperty Export|IncludeGrp|Geometry|TangentsandBinormals -v 1;")
    mel.eval("FBXProperty Export|IncludeGrp|Geometry|Triangulate -v 1;")
    mel.eval("FBXProperty Export|IncludeGrp|Animation -v 1;")
    mel.eval("FBXProperty Export|IncludeGrp|Animation|BakeComplexAnimation -v 1;")
    mel.eval("FBXProperty Export|IncludeGrp|Animation|Deformation -v 1;")
    mel.eval("FBXProperty Export|IncludeGrp|Animation|ConstraintsGrp|Constraint -v 1;")
    mel.eval("FBXProperty Export|IncludeGrp|Animation|ConstraintsGrp|Character -v 1;")
    mel.eval("FBXProperty Export|IncludeGrp|InputConnectionsGrp|InputConnections -v 1;")
    mel.eval("FBXProperty Export|AdvOptGrp|Fbx|AsciiFbx -v \"Binary\";")
    mel.eval("FBXProperty Export|AdvOptGrp|Fbx|ExportFileVersion -v \"FBX201400\";")
    ## Run the export
    mel.eval('FBXExport -f "' + ms_selectedPath + '" -s')
    
    ## Check the file exists
    print ms_selectedPath
    print os.path.exists(ms_selectedPath)
    if os.path.exists(ms_selectedPath) == 1:
        print "SUCCESS :: The file exported successfully.",
    else:
        print "SOMETHING WENT WRONG. Please try again.",

    ## Delete the UI
    cmds.deleteUI('ms_convertInstancer')

    
def browse():
    ## Choose an export path.
    global ms_selectedPath
    pathDialog = cmds.fileDialog2(fileFilter = '*.fbx', dialogStyle = 1, fileMode = 0, caption = "Select where to save the FBX file", okCaption = "Create Here", startingDirectory = 'D:\\Projects\\R&D\\Scenes')
    if pathDialog is not None:
        ms_selectedPath = pathDialog[0]
        cmds.textField('ms_FBXDirectory', edit = True, text = ms_selectedPath)
        cmds.button('ms_convertButton', edit = True, enable = True)
        print "Export path will be >>> %s" % ms_selectedPath,


    

def execute():
    ## Executes the conversion/rigging/exporting   
    selection = cmds.ls(sl=True)
    if cmds.nodeType(selection[0]) == 'instancer':
        if len(selection) != 1:
            cmds.error(" >>>>>>>>>>>>>>   Please select only one instancer at a time <<<<<<<<<<<<<<")
        else:
            convertInstances()
            createBones()
            exportToFBX()
    if cmds.nodeType( selection[0]) == 'MASH_Waiter':
        mel.eval("MASHswitchGeometryType")
        convertInstances()
        createBones()
        exportToFBX()
    else:
        cmds.error(" >>>>>>>>>>>>>>   Please select an instancer node <<<<<<<<<<<<<<")




## Find the path the script is run in and look for the UI file.
fileLoc = __file__ 

print fileLoc
## Replace the py/pyc extension with UI 
if fileLoc.endswith('.py'):
    fileLocReplace = fileLoc.replace(fileLoc[-2:], 'ui')
if fileLoc.endswith('.pyc'):
    fileLocReplace = fileLoc.replace(fileLoc[-3:], 'ui')

## If the UI file exists continue and display the window
if os.path.exists(fileLocReplace):
    ## Verify the SOuP plugin is installed.
    if not cmds.pluginInfo( 'SOuP', query=True, loaded = True ):
        cmds.error(" >>>>>>>>>>>>>>   You need to have SOuP plugin loaded. <<<<<<<<<<<<<<")
    ## Finally display the window.    
    if cmds.window('ms_convertInstancer', exists = True):
        cmds.deleteUI('ms_convertInstancer')
    window = cmds.loadUI(f = fileLocReplace)
    cmds.showWindow(window)
    ## Move the window off the edge and turn it into a toolbox
    cmds.window( window, edit=True, toolbox= True )
    cmds.window( window, edit=True, topEdge= 220, leftEdge = 900 )

# ## Can't find the UI File
# else:
#     cmds.warning('The UI file is not in the correct location. Please fix and try again.')